# Weather Journal App Project

## Table of Contents

 - Introduction
 - The Project Environment
 - Required Steps
 - Resources Used

### **Introduction:**
 
This project requires to create an asynchronous web app that uses Web API 
and user data to dynamically update the UI for a Weather-Journal App.

### **The Project Environment:**

This project needs the following packages to be installed:
 - Node.js
 - Express
 - Body-Parser
 - Cors

### **Required Steps:**

 - Modifying the server.js file
 - Modifying the website/app.js file.
 - Styling the app using style.css

